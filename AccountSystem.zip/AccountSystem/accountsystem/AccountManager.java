
package accountsystem;

import java.util.*;

public class AccountManager {
    static int totalAccounts = 0;
    static User[] users = new User[100];
    public void addUser(String name, int age,String facebookAccount,String instagramAccount, String threadsAccount){
        users[totalAccounts] = new User(name,age,facebookAccount,instagramAccount,threadsAccount);
        totalAccounts++;
    }
    public void displayStatistics(){
    
    }
    public void displayAllUsers() {
    for (int i = 0; i < totalAccounts; i++) {
        User user = users[i];
        System.out.println("----------------------------------");
        System.out.println("Name: " + user.name);
        System.out.println("Age: " + user.age);
        System.out.println("----------------------------------\n");
        System.out.println("Facebook account email: " + user.facebookAccount.email);
        System.out.println("Facebook account Username: " + user.facebookAccount.username);


    }
}

}
