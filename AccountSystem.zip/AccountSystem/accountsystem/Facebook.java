package accountsystem;
import java.time.LocalDateTime;

public class Facebook {
       public static int accountCount = 0;
       User user;
       String email;
       String username;
       LocalDateTime dateCreated;
       
       public Facebook(User user, String email, String username){
           this.user = user;
           this.email = email;
           this.username = username;
           this.dateCreated = LocalDateTime.now();
           
            accountCount++;
       }
       
       public void displayAccountInfo(){
            System.out.println("Email: " + email);
            System.out.println("username: " + username);
            System.out.println("Created: " + dateCreated);
            System.out.println("----------------------------------\n\n");
       }
       
}
