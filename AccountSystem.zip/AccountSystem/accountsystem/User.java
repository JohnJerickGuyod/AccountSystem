/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package accountsystem;

import java.time.LocalDateTime;
import java.util.Scanner;
public class User {
    
    static int userCount = 0;
    
    String name;
    int age;
    LocalDateTime dateCreated;
    Facebook facebookAccount;
    Instagram instagramAccount;
    Threads threadsAccount;
    
        
    
    public User(String name, int age,String facebookAccount,String instagramAccount, String threadsAccount){
        
        Scanner input = new Scanner(System.in);
        
        this.name = name;
        this.age = age;
        if(facebookAccount.equals("1")){
            System.out.print("Email : ");
            String email = input.next();
            System.out.print("Username : ");
            String username = input.next();
            this.facebookAccount = new Facebook(this,email,username);
        }
        
        userCount++;
    }
    
    public void displayUser(){
        System.out.println("Name: " + name);
        System.out.println("Age: " + age);
        System.out.println("Created: " + dateCreated);
        System.out.println("Facebook Account: " + this.facebookAccount);
        System.out.println("instagramAccount: " + instagramAccount);
        System.out.println("Created: " + threadsAccount);
    }
    
}
